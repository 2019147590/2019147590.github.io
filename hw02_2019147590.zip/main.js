async function init() {
    const canvas = document.getElementById("glcanvas");
    const gl = canvas.getContext("webgl");

    if (!gl) {
        alert("WebGL not supported");
        return;
    }

    async function loadShader(url, type) {
        const res = await fetch(url);
        const src = await res.text();
        const shader = gl.createShader(type);
        gl.shaderSource(shader, src);
        gl.compileShader(shader);
        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
            console.error(gl.getShaderInfoLog(shader));
            return null;
        }
        return shader;
    }

    const vs = await loadShader("vertexShader.glsl", gl.VERTEX_SHADER);
    const fs = await loadShader("fragmentShader.glsl", gl.FRAGMENT_SHADER);
    const program = gl.createProgram();
    gl.attachShader(program, vs);
    gl.attachShader(program, fs);
    gl.linkProgram(program);

    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        console.error(gl.getProgramInfoLog(program));
    }
    gl.useProgram(program);

    const size = 0.2;
    const vertices = new Float32Array([
        -size/2, -size/2,
         size/2, -size/2,
         size/2,  size/2,
        -size/2,  size/2
    ]);

    const buffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

    const a_position = gl.getAttribLocation(program, "a_position");
    gl.enableVertexAttribArray(a_position);
    gl.vertexAttribPointer(a_position, 2, gl.FLOAT, false, 0, 0);

    const u_translation = gl.getUniformLocation(program, "u_translation");

    let tx = 0, ty = 0;
    const step = 0.01;

    const min = -1 + size/2;
    const max =  1 - size/2;

    window.addEventListener("keydown", (e) => {
        if (e.key === "ArrowUp")    ty = Math.min(ty + step, max);
        if (e.key === "ArrowDown")  ty = Math.max(ty - step, min);
        if (e.key === "ArrowLeft")  tx = Math.max(tx - step, min);
        if (e.key === "ArrowRight") tx = Math.min(tx + step, max);
        draw();
    });

    function draw() {
        gl.clearColor(0, 0, 0, 1);
        gl.clear(gl.COLOR_BUFFER_BIT);

        gl.uniform2f(u_translation, tx, ty);
        gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);
    }

    draw();
}

init();